# 저장 이름 체크리스트

받은 그림을 아래 이름으로 저장하고 확인 표시를 합니다.

## R1_style_check
- [ ] cover_index.png (1600×900)

## R2_covers_1to3
- [ ] cover_ch1.png (1600×900)
- [ ] cover_ch2.png (1600×900)
- [ ] cover_ch3.png (1600×900)

## R3_covers_4to5
- [ ] cover_ch4.png (1600×900)
- [ ] cover_ch5.png (1600×900)

## R4_comic_ch1
- [ ] cm1_1.png (1200×800)
- [ ] cm1_2.png (1200×800)
- [ ] cm1_3.png (1200×800)
- [ ] cm1_4.png (1200×800)

## R5_comic_ch2
- [ ] cm2_1.png (1200×800)
- [ ] cm2_2.png (1200×800)
- [ ] cm2_3.png (1200×800)
- [ ] cm2_4.png (1200×800)

## R6_comic_ch3
- [ ] cm3_1.png (1200×800)
- [ ] cm3_2.png (1200×800)
- [ ] cm3_3.png (1200×800)
- [ ] cm3_4.png (1200×800)

## R7_comic_ch4
- [ ] cm4_1.png (1200×800)
- [ ] cm4_2.png (1200×800)
- [ ] cm4_3.png (1200×800)
- [ ] cm4_4.png (1200×800)

## R8_comic_ch5
- [ ] cm5_1.png (1200×800)
- [ ] cm5_2.png (1200×800)
- [ ] cm5_3.png (1200×800)
- [ ] cm5_4.png (1200×800)

## 자르기 (생성 안 함)
- [ ] og_index.jpg ← cover_index.png (1200×630)
- [ ] og_ch1.jpg ← cover_ch1.png (1200×630)
- [ ] og_ch2.jpg ← cover_ch2.png (1200×630)
- [ ] og_ch3.jpg ← cover_ch3.png (1200×630)
- [ ] og_ch4.jpg ← cover_ch4.png (1200×630)
- [ ] og_ch5.jpg ← cover_ch5.png (1200×630)
